# MISSION: Hoist yet another to-do manager 'ore Modern Python.
# STATUS: Production
# VERSION: 1.2.0
# NOTES: https://github.com/TotalPythoneering/DoMaster
# DATE: 2026-01-28 06:50:07
# FILE: main.py
# AUTHOR: Randall Nagy
#
import os, sys, shutil
import sqlite3
import uuid
import csv
import datetime

if '..' not in sys.path:
    sys.path.append('..')
from domaster.upsert import UpsertSqlite
from domaster.quit_loop import Loop
from domaster.manage_files import ManageFiles

FILE_ROOT = "domaster.db"
VERSION = "DoMaster 2026.01.27"

class DoMaster(Loop):
    def __init__(self, db_file=None):
        super().__init__()
        self.db_file = None
        self.is_global = True
        if not db_file:
            self.use_global_db()
        else:
            self.use_local_db()
        if not os.path.exists(self.db_file):
            self.init_db()

    def loop_status(self):
        self.init_db()
        print();selection = None
        zdb = 'Db is [GLOBAL]' if self.is_db_global() else 'Db is [LOCAL]'
        if self.is_same_db():
            zdb = 'Db is [SAME]'
        print(zdb)
        print('~'*10)

    def is_db_global(self):
        ''' See if we're using the global database, or no. '''
        return self.is_global

    def use_local_db(self):
        ''' Use the PWD / FOLDER database. '''
        self.db_file = os.path.join(os.getcwd(), FILE_ROOT)
        self.is_global = False

    def use_global_db(self):
        ''' Use the MODULE / GLOBAL database. '''
        root = os.path.dirname(os.path.abspath(__file__))
        self.db_file = os.path.join(root, FILE_ROOT)
        self.is_global = True

    def is_same_db(self):
        ''' Edgy condition - some times they're the same. '''
        a_root = os.path.dirname(os.path.abspath(__file__))
        a_db = os.path.join(a_root, FILE_ROOT)
        b_db = os.path.join(os.getcwd(), FILE_ROOT)
        return a_db == b_db

    def short_db_name(self):
        ''' Print a mnemonic name for the database. '''
        zfile = self.db_file
        if len(zfile) > 25:
            zfile = '...' + zfile[-25:]
        return zfile

    def swap_db(self):
        ''' Toggle GLOBAL database on/off. '''
        if self.is_db_global():
            self.use_local_db()
        else:
            self.use_global_db()
        print(f"Now using {self.short_db_name()} Datbase.")

    def get_fields(self, system=False)->list:
        ''' Manage the two 'flavors' of the files sets. '''
        results = [
                    'ID',
                    'uuid',
                    'project_name',
                    'date_created',
                    'date_done',
                    'task_description',
                    'task_priority',
                    'next_task'
            ]
        if not system:
            results.remove('uuid')
        return results

    def humanize(self, obj)->list:
        ''' Convert database tags to 'humanized' title-case. '''
        if isinstance(obj, dict):
            return self.humanize(obj.keys())
        elif isinstance(obj, list):
            result = []
            for fld in obj:
                result.append(fld.replace('_', ' ').title())
            return result
        elif isinstance(obj, str):
            return obj.replace('_', ' ').title()
        return obj # gigo
       
    def get_now(self):
        ''' Project `now` time. '''
        return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def init_db(self):
        ''' Create table if not exist. '''
        conn = sqlite3.connect(self.db_file)
        conn.execute(f"""
            CREATE TABLE IF NOT EXISTS todo (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                uuid TEXT UNIQUE,
                project_name TEXT,
                date_created TEXT,
                date_done TEXT,
                task_description TEXT,
                task_priority INTEGER,
                next_task INTEGER DEFAULT 0
            )
        """)
        conn.commit()
        conn.close()

    def count(self):
        ''' Count the items in the TODO table. '''
        try:
            conn = sqlite3.connect(self.db_file)
            count_query = f"SELECT COUNT(*) FROM todo;"
            result = conn.execute(count_query)
            tally = int(result.fetchone()[0])
            return tally
        except Exception as ex:
            print(ex)
        finally:
            conn.close()
        return 0

    def add_task(self):
        ''' Add a task to the database. '''
        print("\n--- Add New Task ---")
        proj = input("Project Name: ")
        desc = input("Description: ")
        pri = input("Priority (Integer): ")
        next_t = input("Next Task ID (Default 0): ") or 0
        
        conn = sqlite3.connect(self.db_file)
        conn.execute("""INSERT INTO todo (uuid, project_name, date_created, task_description, task_priority, next_task) 
                     VALUES (?, ?, ?, ?, ?, ?)""", 
                     (str(uuid.uuid4()),
                      proj, self.get_now(),
                      desc, pri, next_t))
        conn.commit()
        conn.close()
        print("Task added successfully.")

    def delete_task(self)->None:
        ''' Remove a task from the database. '''
        if self.count() == 0:
            print("Database is empty.")
            return 0
        tid = input("Enter ID to delete: ").strip()
        if not tid:
            return
        conn = sqlite3.connect(self.db_file)
        conn.execute(f"DELETE FROM todo WHERE ID = ?", (tid))
        conn.commit()
        conn.close()

    def update_task(self)->None:
        ''' Update a task in the database. '''
        if self.count() == 0:
            print("Database is empty.")
            return 0
        tid = input("Enter ID to update: ").strip()
        if not tid:
            return
        fields = self.get_fields()
        fields.remove('ID')
        print("Available fields:")
        for ss, field in enumerate(self.humanize(fields),1):
            print(f'{ss:02}.) {field}') 
        which = input("Field # to update: ").strip()
        if not which:
            return
        try:
            which = int(which)
            which -= 1
            field = fields[which]
        except:
            print("Invalid field number.")
            return
        del which
        new_val = input(f"New value for {field}: ").strip()
        if not new_val:
            print("Aborted.")
            return
        conn = sqlite3.connect(self.db_file)
        conn.execute(f"UPDATE todo SET {field} = ? WHERE ID = ?", (new_val, tid))
        conn.commit()
        conn.close()

    def mark_done(self):
        ''' Date task ID completed. '''
        tid = input("Enter Task ID to mark as done: ").strip()
        if not tid:
            print("Aborted.")
            return
        conn = sqlite3.connect(self.db_file)
        conn.execute("UPDATE todo SET date_done = ? WHERE ID = ?", (self.get_now(), tid))
        conn.close()

    def list_tasks(self,filter_type="all"):
        print(self.short_db_name())
        fields = self.get_fields()
        query = f"SELECT {', '.join(fields)} FROM todo"
        if filter_type == "pending":
            query += " WHERE date_done IS NULL OR date_done = ''"
        elif filter_type == "done":
            query += " WHERE date_done IS NOT NULL AND date_done != ''"        
        query += " ORDER BY project_name ASC, task_priority ASC"        
        conn = sqlite3.connect(self.db_file)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(query).fetchall()
        count = 0
        for r in rows:
            count += 1
            print('*'*15)
            print(f"ID      : [{r['ID']:03}]", f"   Next: [{r['next_task']:03}]")
            print(f"Project : [{r['project_name']:<15}]")
            print(f"Priority: [{r['task_priority']:02}]")
            print(f"Created : [{r['date_created']:<15}]")
            print(f"Description: \n\t  [{r['task_description']:<15}]")
        conn.close()
        print(f"View [{filter_type.upper()}] is {count:03} of {self.count():03} items.")

    def list_pending(self):
        ''' List pending tasks. '''
        self.list_tasks("pending")

    def list_done(self):
        ''' List completed tasks. '''
        self.list_tasks("done")

    def list_all(self):
        ''' List all tasks. '''
        self.list_tasks("all")

    def project_report(self):
        ''' Show all project names. '''
        conn = sqlite3.connect(self.db_file)
        projs = conn.execute("SELECT DISTINCT project_name FROM todo ORDER BY project_name").fetchall()
        for p in projs: print(f"- {p[0]}")
        conn.close()

    def manage_files(self)->None:
        ''' Manage local files. '''
        ops = ManageFiles(self)
        ops.mainloop()


def mainloop():
    ops = DoMaster()
    options = {
        'Add Task':ops.add_task,
        'Delete Task':ops.delete_task,
        'Update Task':ops.update_task,
        'Mark Completed':ops.mark_done,
        'List Pendings':ops.list_pending,
        'List Done':ops.list_done,
        'List All':ops.list_all,
        'Projects':ops.project_report,
        'Swap Db':ops.swap_db,
        'File Manager':ops.manage_files,
        'Quit':ops.do_quit
        }
    Loop.MenuOps(ops, options, VERSION)

if __name__ == "__main__":
    mainloop()
